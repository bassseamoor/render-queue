@echo off
rem MOOR-Phone-Sync.cmd -- pulls your phone-built apps into this PC's Moor.
rem Self-updating: always fetches the newest phone-sync.py before running it.
cd /d "%USERPROFILE%\Downloads"
where curl.exe >nul 2>nul
if %errorlevel%==0 (
  curl.exe -sSL -o phone-sync.py "https://raw.githubusercontent.com/bassseamoor/render-queue/main/phone-sync/phone-sync.py"
) else (
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/bassseamoor/render-queue/main/phone-sync/phone-sync.py' -OutFile \"$env:USERPROFILE\Downloads\phone-sync.py\""
)
python phone-sync.py
pause
